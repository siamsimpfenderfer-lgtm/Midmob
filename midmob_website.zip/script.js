
function handleSubmit(e){
  e.preventDefault();
  const form = e.target;
  const data = new FormData(form);
  const name = data.get('name') || '';
  const email = data.get('email') || '';
  const phone = data.get('phone') || '';
  const message = data.get('message') || '';
  const subject = encodeURIComponent('Midmob Booking Inquiry from ' + name);
  const body = encodeURIComponent('Name: ' + name + '\nEmail: ' + email + '\nPhone: ' + phone + '\n\nMessage:\n' + message);
  const mailto = 'mailto:siamsimpfenderfer@gmail.com?subject=' + subject + '&body=' + body;
  window.location.href = mailto;
  const status = document.getElementById('formStatus');
  status.textContent = 'Opening your email client to complete the message...';
}
