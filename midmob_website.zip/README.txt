Midmob — Website package (clean white & gold, spiritual-minimal)

Files:
- index.html
- styles.css
- script.js
- midmob_logo_01.png

Notes:
- Contact email is set to siamsimpfenderfer@gmail.com. Change in index.html if needed.
- Calendly embed placeholder is present. When you have a Calendly link, replace the contact section text or add an iframe with your link.
- To publish: upload files to any static host (Netlify, GitHub Pages, Vercel, or simple web host).
